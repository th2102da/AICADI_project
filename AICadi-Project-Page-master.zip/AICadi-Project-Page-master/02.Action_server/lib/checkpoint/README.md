## Video Demo
Firtst, you need to download the pretrained weights for YOLOv3 ([here](https://drive.google.com/file/d/1YgA9riqm0xG2j72qhONi5oyiAxc98Y1N/view?usp=sharing)), HRNet ([here](https://drive.google.com/drive/folders/https://drive.google.com/file/d/1YLShFgDJt2Cs9goDw9BmR-UzFVgX3lc8/view?usp=sharing)) and put them in the './demo/lib/checkpoint' directory. Then, put your in-the-wild videos in the './demo/video' directory. 

Note: make sure you have also downloaded the weights for PoseFormerV2! (the default path in the code is './checkpoint')
